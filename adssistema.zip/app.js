import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, sendEmailVerification, EmailAuthProvider, reauthenticateWithCredential, updatePassword, updateEmail } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, collection, addDoc, getDocs, query, orderBy, deleteDoc, updateDoc, where } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAMyiwLVncwCH4y9-6LhyBQyibq-YhUMzM",
  authDomain: "xis-fabrica.firebaseapp.com",
  projectId: "xis-fabrica"
};

// Inicializa o Firebase com as credenciais
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const secretKey = "XisFabrica2026Secret";

// Variáveis globais para controlar o estado do usuário e temporizadores
let currentUserData = null;
let currentAuthUser = null; 
let temporizador2FA;
let tempoRestante = 180;
let chartInst1 = null;
let chartInst2 = null;
let carouselInterval = null;

// ================= FUNÇÕES AUXILIARES GLOBAIS =================
// Formata a quantidade para evitar números dízimas como 2.5999999999
window.fmtQtd = (q) => {
    if(q === null || q === undefined || isNaN(q)) return 0;
    return parseFloat(Number(q).toFixed(3));
};

// ================= SISTEMA DE POPUPS CUSTOMIZADOS (ALERTS / PROMPTS / CONFIRMS) =================
const modalStyle = document.createElement('style');
modalStyle.innerHTML = `
    .custom-modal-overlay { position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); display:flex; align-items:center; justify-content:center; z-index:99999; }
    .custom-modal-box { background:var(--card-bg, #fff); color:var(--text-color, #333); padding:20px 30px; border-radius:10px; max-width:400px; width:90%; text-align:center; box-shadow:0 4px 20px rgba(0,0,0,0.3); border:1px solid var(--border-color, #ccc); font-family:sans-serif; }
    .custom-modal-box p { margin-bottom: 15px; font-size: 16px; line-height: 1.4; white-space: pre-wrap; }
    .custom-modal-box input, .custom-modal-box select { width:100%; margin:10px 0; padding:12px; border:1px solid var(--border-color, #ccc); border-radius:6px; background:var(--bg, #f9f9f9); color:var(--text-color, #333); font-size:14px; }
    .custom-modal-buttons { display:flex; justify-content:center; gap:10px; margin-top:20px; }
    .custom-modal-btn { padding:10px 20px; border:none; border-radius:6px; cursor:pointer; font-weight:bold; font-size:14px; transition:0.2s; }
    .custom-modal-btn-primary { background:var(--primary, #d32f2f); color:#fff; }
    .custom-modal-btn-primary:hover { filter:brightness(0.9); }
    .custom-modal-btn-secondary { background:#777; color:#fff; }
    .custom-modal-btn-secondary:hover { filter:brightness(0.9); }
`;
document.head.appendChild(modalStyle);

window.createCustomModal = (msg, type = 'alert', defaultText = '') => {
    return new Promise((resolve) => {
        const overlay = document.createElement('div');
        overlay.className = 'custom-modal-overlay';
        
        const box = document.createElement('div');
        box.className = 'custom-modal-box';
        
        const text = document.createElement('p');
        text.innerHTML = msg.replace(/\n/g, '<br>');
        box.appendChild(text);
        
        let input;
        if (type === 'prompt') {
            input = document.createElement('input');
            input.type = 'text';
            input.value = defaultText;
            box.appendChild(input);
            setTimeout(() => input.focus(), 100);
        }
        
        const btnGroup = document.createElement('div');
        btnGroup.className = 'custom-modal-buttons';
        
        if (type === 'confirm' || type === 'prompt') {
            const btnCancel = document.createElement('button');
            btnCancel.className = 'custom-modal-btn custom-modal-btn-secondary';
            btnCancel.innerText = 'Cancelar';
            btnCancel.onclick = () => { document.body.removeChild(overlay); resolve(null); };
            btnGroup.appendChild(btnCancel);
        }
        
        const btnOk = document.createElement('button');
        btnOk.className = 'custom-modal-btn custom-modal-btn-primary';
        btnOk.innerText = 'OK';
        btnOk.onclick = () => { 
            document.body.removeChild(overlay); 
            if(type === 'prompt') resolve(input.value);
            else if(type === 'confirm') resolve(true);
            else resolve(true); 
        };
        btnGroup.appendChild(btnOk);
        
        box.appendChild(btnGroup);
        overlay.appendChild(box);
        document.body.appendChild(overlay);
    });
};

window.customAlert = (msg) => createCustomModal(msg, 'alert');
window.customConfirm = (msg) => createCustomModal(msg, 'confirm');
window.customPrompt = (msg, defaultVal='') => createCustomModal(msg, 'prompt', defaultVal);

// ================= MODO NOTURNO & RESPONSIVIDADE MOBILE =================
window.toggleDarkMode = () => {
    document.body.classList.toggle('dark-mode');
    const isDark = document.body.classList.contains('dark-mode');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    document.querySelectorAll('.theme-toggle-btn i').forEach(icon => {
        icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
    });
};

if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-mode');
}

window.toggleSidebar = () => {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('open');
};

// ================= CRIPTOGRAFIA & UTILITÁRIOS =================
window.encrypt = (text) => CryptoJS.AES.encrypt(text, secretKey).toString();

window.safeDecrypt = (text) => {
    if (!text) return "";
    try { const bytes = CryptoJS.AES.decrypt(text, secretKey); return bytes.toString(CryptoJS.enc.Utf8) || text; } catch (e) { return text; }
};

window.formatCPF = (cpf) => cpf.replace(/\D/g, "").replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
window.maskCPF = (cpf) => cpf.replace(/\D/g, '').replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.***.***-$4");

window.logAction = async (userEmail, userName, action, item, details) => {
    await addDoc(collection(db, "logs"), { 
        userEmail: window.encrypt(userEmail), 
        userName: window.encrypt(userName), 
        action: window.encrypt(action), 
        item: window.encrypt(item), 
        details: window.encrypt(details), 
        timestamp: new Date().toISOString() 
    });
};

window.atualizarFotoPerfil = async (input, previewId) => {
    const url = await uploadImage(input, previewId);
    if (url) {
        configUrlAvatar = url;
        try {
            await updateDoc(doc(db, "users", currentUserData.email_plain), { foto_url: url });
            currentUserData.foto_url = url;
            const userPhotoEl = document.getElementById('user-display-photo');
            if (userPhotoEl) userPhotoEl.src = url;
            await customAlert('Foto de perfil atualizada e salva com sucesso!');
        } catch(e) {
            console.error("Erro ao salvar no Firebase:", e);
            await customAlert('A foto subiu, mas falhou ao salvar na base de dados.');
        }
    }
};

window.atualizarFotoReceita = async (input, previewId) => {
    const url = await uploadImage(input, previewId);
    if (url) {
        recUrlImg = url; 
    }
};

window.uploadImage = async (input, imgPreviewId) => {
    const file = input.files[0];
    if(!file) return null;
    const formData = new FormData();
    formData.append('file', file);
    try {
        const res = await fetch('upload.php', { method: 'POST', body: formData });
        const textData = await res.text();
        
        let cleanJson = textData;
        const jsonStart = textData.indexOf('{');
        const jsonEnd = textData.lastIndexOf('}');
        if (jsonStart !== -1 && jsonEnd !== -1) {
            cleanJson = textData.substring(jsonStart, jsonEnd + 1);
        }

        const data = JSON.parse(cleanJson);
        const urlFinal = data.url || data.caminho || data.file;

        if((data.success || data.sucesso) && urlFinal) {
            if(imgPreviewId) {
                const imgEl = document.getElementById(imgPreviewId);
                if (imgEl) {
                    imgEl.src = urlFinal;
                    imgEl.style.display = 'block';
                }
            }
            return urlFinal;
        } else { 
            await customAlert("Erro no upload: " + (data.error || "O PHP salvou a imagem mas não retornou a URL corretamente.")); 
            return null; 
        }
    } catch(e) { 
        await customAlert("Erro ao ler resposta do PHP. Detalhe: " + e.message);
        return null; 
    }
};

window.converterUnidade = (qtd, unRec, unEst) => {
    let q = parseFloat(qtd);
    if (unRec === unEst) return q;
    if (unRec === 'ml' && (unEst === 'L' || unEst === 'l')) return q / 1000;
    if ((unRec === 'L' || unRec === 'l') && unEst === 'ml') return q * 1000;
    if (unRec === 'g' && unEst === 'kg') return q / 1000;
    if (unRec === 'kg' && unEst === 'g') return q * 1000;
    return q; 
};

// Adiciona regras restritas de conversão para selects de unidade, garantindo semelhança (Kg/g) e (L/ml)
window.atualizarOpcoesUnidadeUI = (selectId, unidadeEstoque) => {
    const select = document.getElementById(selectId);
    if(!select) return;
    select.innerHTML = "";
    if (unidadeEstoque === 'kg' || unidadeEstoque === 'g') {
        select.innerHTML = `<option value="g">g (Gramas)</option><option value="kg">kg (Kilos)</option>`;
    } else if (unidadeEstoque === 'L' || unidadeEstoque === 'ml' || unidadeEstoque === 'l') {
        select.innerHTML = `<option value="ml">ml (Mililitros)</option><option value="L">L (Litros)</option>`;
    } else if (unidadeEstoque === 'fatia') {
        select.innerHTML = `<option value="fatia">fatia</option>`;
    } else {
        select.innerHTML = `<option value="un">un (Unidade)</option>`;
    }
    select.value = unidadeEstoque; // Seta a unidade padrão como a do estoque
};

window.atualizarOpcoesUnidadeReceita = (unidadeEstoque) => {
    window.atualizarOpcoesUnidadeUI('rec-ing-unidade', unidadeEstoque);
};

IMask(document.getElementById('reg-telefone'), { mask: '(00) 00000-0000' });
IMask(document.getElementById('reg-cpf'), { mask: '000.000.000-00' });
IMask(document.getElementById('rec-cpf'), { mask: '000.000.000-00' });
IMask(document.getElementById('2fa-code-input'), { mask: '000000' });

window.togglePassword = (inputId, icon) => {
    const input = document.getElementById(inputId);
    input.type = input.type === "password" ? "text" : "password";
    icon.classList.toggle('fa-eye'); icon.classList.toggle('fa-eye-slash');
};

window.checkPasswordStrength = (inputId, listId) => {
    const v = document.getElementById(inputId).value;
    const reqs = {
        'req-len': v.length >= 8,
        'req-upper': /[A-Z]/.test(v),
        'req-num': /\d/.test(v),
        'req-spec': /[@$!%*?&#]/.test(v)
    };
    for (let id in reqs) {
        const li = document.querySelector(`#${listId} #${id}`);
        if(reqs[id]) { li.classList.replace('invalid', 'valid'); li.querySelector('i').classList.replace('fa-times', 'fa-check'); }
        else { li.classList.replace('valid', 'invalid'); li.querySelector('i').classList.replace('fa-check', 'fa-times'); }
    }
    return Object.values(reqs).every(b => b);
};

// ================= LOGIN, REGISTRO E RECUPERAÇÃO =================
document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    document.getElementById('login-error').style.display = 'none';
    try {
        const userCred = await signInWithEmailAndPassword(auth, document.getElementById('login-email').value, document.getElementById('login-password').value);
        currentAuthUser = userCred.user;
        iniciar2FA();
    } catch (error) {
        document.getElementById('login-error').style.display = 'block'; document.getElementById('login-error').innerText = `Credenciais inválidas.`;
    }
});

document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('reg-email').value.toLowerCase();
    const senha = document.getElementById('reg-senha').value;
    
    if(!checkPasswordStrength('reg-senha', 'pass-reqs')) return await customAlert("Senha não atende aos requisitos.");
    if(senha !== document.getElementById('reg-senha-rep').value) return await customAlert("As senhas não conferem.");

    try {
        const userCred = await createUserWithEmailAndPassword(auth, email, senha);
        const fullName = document.getElementById('reg-nome').value + ' ' + document.getElementById('reg-sobrenome').value;
        
        await setDoc(doc(db, "users", email), {
            uid: userCred.user.uid, 
            role: "operacional", 
            nome: encrypt(fullName), 
            email: encrypt(email), 
            telefone: encrypt(document.getElementById('reg-telefone').value), 
            cpf: encrypt(document.getElementById('reg-cpf').value),
            foto_url: "", 
            createdAt: new Date().toISOString()
        });
        await sendEmailVerification(userCred.user);
        await customAlert("Cadastro realizado! Verifique seu e-mail para validar a conta.");
        await signOut(auth); document.getElementById('flip-wrapper').classList.remove('flipped');
    } catch (error) { await customAlert("Erro ao cadastrar: " + error.message); }
});

window.showRecoverForm = () => { document.getElementById('flip-wrapper').style.display = 'none'; document.getElementById('recover-form').style.display = 'block'; };
window.voltarAoLogin = () => { document.getElementById('recover-form').style.display = 'none'; document.getElementById('recover-step-2').style.display = 'none'; document.getElementById('recover-step-1').style.display = 'block'; document.getElementById('flip-wrapper').style.display = 'block'; };

let tempRecEmail = ""; let tempRecCode = "";

window.enviarCodigoRecuperacao = async () => {
    const email = document.getElementById('rec-email').value.toLowerCase();
    const cpf = document.getElementById('rec-cpf').value;
    if(!email || !cpf) return await customAlert("Preencha email e CPF.");
    
    const docSnap = await getDoc(doc(db, "users", email));
    if(!docSnap.exists() || safeDecrypt(docSnap.data().cpf) !== cpf) {
        return await customAlert("Dados não conferem no sistema.");
    }
    
    tempRecEmail = email; tempRecCode = Math.floor(100000 + Math.random() * 900000).toString();
    await customAlert(`[SIMULAÇÃO] Código enviado para o email: ${tempRecCode}`);
    document.getElementById('recover-step-1').style.display = 'none'; document.getElementById('recover-step-2').style.display = 'block';
};

window.validarCodigoENovaSenha = async () => {
    const code = document.getElementById('rec-code').value;
    const newPass = document.getElementById('rec-new-pass').value;
    if(code !== tempRecCode) return await customAlert("Código incorreto!");
    if(!checkPasswordStrength('rec-new-pass', 'rec-pass-reqs')) return await customAlert("Senha não atende aos requisitos.");
    import("https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js").then(m => {
        m.sendPasswordResetEmail(auth, tempRecEmail).then(async ()=> { await customAlert("Um link de redefinição real foi enviado ao seu email."); voltarAoLogin(); });
    });
};

// ================= 2FA LÓGICA =================
window.iniciar2FA = async () => {
    const codigo2FA = Math.floor(100000 + Math.random() * 900000).toString();
    await setDoc(doc(db, "2fa_codes", currentAuthUser.email), { codigo: codigo2FA, expiraEm: Date.now() + (3 * 60 * 1000) });
    await customAlert(`[SIMULAÇÃO E-MAIL]\nSeu código de acesso é: ${codigo2FA}`);
    document.getElementById('flip-wrapper').style.display = 'none'; document.getElementById('two-factor-form').style.display = 'block';
    document.getElementById('2fa-email-display').innerText = currentAuthUser.email;
    document.getElementById('2fa-code-input').value = ""; document.getElementById('2fa-error').style.display = 'none';
    iniciarTimer2FA();
};

window.iniciarTimer2FA = () => {
    clearInterval(temporizador2FA); tempoRestante = 180; 
    document.getElementById('btn-resend-2fa').disabled = true; document.getElementById('btn-resend-2fa').style.opacity = '0.5';
    const circle = document.querySelector('.progress-ring__circle');
    const circumference = circle.r.baseVal.value * 2 * Math.PI;

    temporizador2FA = setInterval(() => {
        tempoRestante--;
        document.getElementById('2fa-timer-text').innerText = `${Math.floor(tempoRestante/60).toString().padStart(2,'0')}:${(tempoRestante%60).toString().padStart(2,'0')}`;
        circle.style.strokeDashoffset = circumference - (tempoRestante / 180) * circumference;
        if (tempoRestante <= 0) {
            clearInterval(temporizador2FA); document.getElementById('btn-resend-2fa').disabled = false;
            document.getElementById('btn-resend-2fa').style.opacity = '1'; document.getElementById('2fa-error').style.display = 'block'; document.getElementById('2fa-error').innerText = "Código expirado.";
        }
    }, 1000);
};

window.validarCodigo2FA = async () => {
    const inputCodigo = document.getElementById('2fa-code-input').value;
    if(inputCodigo.length < 6) return;
    const docSnap = await getDoc(doc(db, "2fa_codes", currentAuthUser.email));
    if (docSnap.exists() && Date.now() <= docSnap.data().expiraEm && docSnap.data().codigo === inputCodigo) {
        await deleteDoc(doc(db, "2fa_codes", currentAuthUser.email)); clearInterval(temporizador2FA);
        document.getElementById('auth-container').style.display = 'none'; document.getElementById('app-container').style.display = 'flex';
        loadDashboard(currentAuthUser);
    } else { document.getElementById('2fa-error').style.display = 'block'; document.getElementById('2fa-error').innerText = "Código incorreto ou expirado."; }
};

window.cancelar2FA = async () => { clearInterval(temporizador2FA); await signOut(auth); currentAuthUser = null; document.getElementById('two-factor-form').style.display = 'none'; document.getElementById('flip-wrapper').style.display = 'block'; };
window.logout = async () => { await signOut(auth); location.reload(); };

// ================= ROTEAMENTO & DASHBOARD =================
async function loadDashboard(user) {
    const emailAuth = user.email.toLowerCase();
    let userDoc = await getDoc(doc(db, "users", emailAuth));
    
    if (!userDoc.exists() && emailAuth === "rayaneduuq@gmail.com") {
        await setDoc(doc(db, "users", emailAuth), { uid: user.uid, role: "admin", nome: encrypt("Raiany Duque"), email: encrypt(emailAuth), telefone: encrypt("(35) 99115-1080"), cpf: encrypt("123.282.716-51"), foto_url: "", createdAt: new Date().toISOString() });
        userDoc = await getDoc(doc(db, "users", emailAuth));
    }
    if(!userDoc.exists()) return await customAlert("Perfil não encontrado.");

    currentUserData = userDoc.data();
    currentUserData.email_plain = emailAuth; 

    document.getElementById('user-display-name').innerText = safeDecrypt(currentUserData.nome).split(' ')[0];
    document.getElementById('user-display-role').innerText = currentUserData.role === 'admin' ? "Administrador" : "Operacional";
    if(currentUserData.foto_url) document.getElementById('user-display-photo').src = currentUserData.foto_url;
    
    const menu = document.getElementById('menu-items');
    if (currentUserData.role === 'admin') {
        menu.innerHTML = `
            <li id="m-dash" onclick="renderAdminDash(); toggleSidebar();"><i class="fas fa-chart-pie"></i> Dashboard</li>
            <li id="m-est" onclick="renderInsumos(); toggleSidebar();"><i class="fas fa-boxes"></i> Estoque</li>
            <li id="m-rec" onclick="renderReceitas(); toggleSidebar();"><i class="fas fa-hamburger"></i> Receitas</li>
            <li id="m-eq" onclick="renderEquipe(); toggleSidebar();"><i class="fas fa-users"></i> Equipe</li>
            <li id="m-log" onclick="renderAuditoria(); toggleSidebar();"><i class="fas fa-shield-alt"></i> Histórico</li>
            <li id="m-cfg" onclick="renderConfig(); toggleSidebar();"><i class="fas fa-cog"></i> Configurações</li>
        `;
        renderAdminDash();
    } else {
        menu.innerHTML = `
            <li id="m-bax" onclick="renderBaixas(); toggleSidebar();"><i class="fas fa-bolt"></i> Produção</li>
            <li id="m-ava" onclick="renderAvarias(); toggleSidebar();"><i class="fas fa-trash-alt"></i> Avarias</li>
            <li id="m-cfg" onclick="renderConfig(); toggleSidebar();"><i class="fas fa-cog"></i> Minha Conta</li>
        `;
        renderBaixas();
    }
}

function setActiveMenu(id) { document.querySelectorAll('#menu-items li').forEach(l=>l.classList.remove('active')); if(document.getElementById(id)) document.getElementById(id).classList.add('active'); }

let currentCarouselIdx = 0;
function iniciarCarrossel() {
    if (carouselInterval) clearInterval(carouselInterval);
    currentCarouselIdx = 0;
    const slides = document.querySelectorAll('.carousel-slide');
    if (!slides || slides.length === 0) return;
    slides.forEach((slide, i) => { if (i === 0) { slide.classList.add('active'); } else { slide.classList.remove('active'); } });
    carouselInterval = setInterval(() => {
        const currentSlides = document.querySelectorAll('.carousel-slide');
        if (!currentSlides || currentSlides.length === 0) { clearInterval(carouselInterval); return; }
        currentSlides[currentCarouselIdx].classList.remove('active');
        currentCarouselIdx = (currentCarouselIdx + 1) % currentSlides.length;
        currentSlides[currentCarouselIdx].classList.add('active');
    }, 4000);
}

// ================= TELA: ADMIN DASHBOARD =================
let clockInterval;

window.renderAdminDash = async () => {
    setActiveMenu('m-dash'); 
    clearInterval(clockInterval);
    if (carouselInterval) clearInterval(carouselInterval);
    
    document.getElementById('main-content').innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px; flex-wrap:wrap; gap:15px;">
            <h2><i class="fas fa-chart-pie"></i> Dashboard</h2>
            <div style="display:flex; gap:15px; align-items:center; flex-wrap:wrap;">
                <select id="grafico-filtro" onchange="renderGraficos()" style="margin:0; padding:10px;">
                    <option value="mes">Este Mês</option>
                    <option value="ano">Este Ano</option>
                    <option value="tudo">Tudo</option>
                </select>
                <div class="clock-widget"><i class="fas fa-clock"></i> <span id="br-clock">--:--:--</span></div>
                <button class="btn-primary" style="width:auto;" onclick="gerarRelatorioPrint()"><i class="fas fa-print"></i> Relatório PDF</button>
            </div>
        </div>

        <div class="carousel-container">
            <div class="carousel-slide active">
                <img src="img/banner1.png" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1000';" alt="Destaque 1">
                <div class="carousel-caption">Padrão de Qualidade Xis Fábrica</div>
            </div>
            <div class="carousel-slide">
                <img src="img/banner2.png" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1586190848861-99aa4a171e90?q=80&w=1000';" alt="Destaque 2">
                <div class="carousel-caption">Controle Absoluto de Estoque & Produção</div>
            </div>
            <div class="carousel-slide">
                <img src="img/banner3.png" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=1000';" alt="Destaque 3">
                <div class="carousel-caption">Eficiência e Desempenho Diário</div>
            </div>
        </div>
        
        <details id="detalhes-notif-admin" style="margin-bottom:20px; background:var(--card-bg); padding:10px; border:1px solid var(--border-color); border-radius:8px;">
            <summary style="font-weight:bold; cursor:pointer; color:#b71c1c;"><i class="fas fa-bell"></i> Notificações de Estoque (<span id="notif-count">0</span>)</summary>
            <div id="alertas-container" style="margin-top:10px;"></div>
            <div id="validades-container"></div>
        </details>

        <div class="grid-4" style="margin-bottom: 20px; display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div class="card" style="text-align:center;">
                <i class="fas fa-utensils fa-2x" style="color:#1976d2;"></i>
                <h4 style="margin: 10px 0 5px 0;">Receitas Feitas</h4>
                <h2 id="card-receitas">0</h2>
            </div>
            <div class="card" style="text-align:center;">
                <i class="fas fa-trash-alt fa-2x" style="color:#f57c00;"></i>
                <h4 style="margin: 10px 0 5px 0;">Perdas / Avarias</h4>
                <h2 id="card-avarias">0</h2>
            </div>
            <div class="card" style="text-align:center;">
                <i class="fas fa-skull-crossbones fa-2x" style="color:#d32f2f;"></i>
                <h4 style="margin: 10px 0 5px 0;">Produtos Vencidos</h4>
                <h2 id="card-vencidos">0</h2>
            </div>
            <div class="card" style="text-align:center;">
                <i class="fas fa-exclamation-triangle fa-2x" style="color:#ff9800;"></i>
                <h4 style="margin: 10px 0 5px 0;">Estoque Acabando</h4>
                <h2 id="card-acabando">0</h2>
            </div>
        </div>

        <div class="grid-2" style="margin-top:20px;">
            <div class="card"><h3><i class="fas fa-cubes"></i> Estoque Atual (Qtd)</h3><canvas id="graficoEstoque"></canvas></div>
            <div class="card"><h3><i class="fas fa-exchange-alt"></i> Produção vs Avarias</h3><canvas id="graficoComparacao"></canvas></div>
        </div>
    `;

    iniciarCarrossel();

    clockInterval = setInterval(() => {
        const now = new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", dateStyle: "short", timeStyle: "medium" });
        if(document.getElementById('br-clock')) document.getElementById('br-clock').innerText = now;
    }, 1000);

    const snaps = await getDocs(collection(db, "insumos"));
    const cAlerta = document.getElementById('alertas-container');
    const cValid = document.getElementById('validades-container');
    
    let estoqueNomes = [], estoqueQtd = [];
    const hoje = new Date();
    
    let countNotifs = 0; let numVencidos = 0; let numAcabando = 0;

    snaps.forEach(s => { 
        const d = s.data();
        estoqueNomes.push(d.nome); estoqueQtd.push(fmtQtd(d.qtd)); 
        
        if (d.qtd < 0) { 
            cAlerta.innerHTML += `<div class="alert-box alert-danger" style="border: 2px solid #b71c1c; background: rgba(183, 28, 28, 0.1);"><i class="fas fa-exclamation-triangle" style="color: #b71c1c;"></i><div><strong style="color: #b71c1c;">ESTOQUE INCORRETO (NEGATIVO):</strong> ${d.nome} (Lote: ${d.lote||'N/A'}) consta com saldo de ${fmtQtd(d.qtd)} ${d.unidade||'un'}. Verifique os registros imediatamente!</div></div>`; 
            countNotifs++;
        } else if (d.qtd <= d.min_qtd) { 
            cAlerta.innerHTML += `<div class="alert-box alert-danger"><i class="fas fa-exclamation-triangle"></i><div><strong>Estoque Crítico:</strong> ${d.nome} (Lote: ${d.lote||'N/A'}) com ${fmtQtd(d.qtd)} ${d.unidade||'un'} (Mín: ${fmtQtd(d.min_qtd)} ${d.unidade||'un'}).</div></div>`; 
            countNotifs++; numAcabando++;
        } else if (d.qtd <= (d.min_qtd * 1.5)) { 
            cAlerta.innerHTML += `<div class="alert-box alert-warning"><i class="fas fa-exclamation-circle"></i><div><strong>Atenção:</strong> ${d.nome} próximo do limite (${fmtQtd(d.qtd)} ${d.unidade||'un'}).</div></div>`; 
            countNotifs++; numAcabando++;
        }
        
        if(d.validade) {
            const dataVal = new Date(d.validade);
            const diffDias = Math.ceil((dataVal - hoje) / (1000 * 60 * 60 * 24));
            if(diffDias < 0) {
                cValid.innerHTML += `<div class="alert-box alert-danger"><i class="fas fa-skull-crossbones"></i><div><strong>Vencido:</strong> ${d.nome} venceu em ${new Date(d.validade).toLocaleDateString('pt-BR')} (Lote: ${d.lote||'N/A'})! Descarte o item.</div></div>`;
                countNotifs++; numVencidos++;
            }
            else if(diffDias <= 7) {
                cValid.innerHTML += `<div class="alert-box alert-warning"><i class="fas fa-calendar-times"></i><div><strong>Vence em ${diffDias} dias:</strong> ${d.nome} (${new Date(d.validade).toLocaleDateString('pt-BR')}).</div></div>`;
                countNotifs++;
            }
        }
    });

    document.getElementById('notif-count').innerText = countNotifs;
    document.getElementById('card-vencidos').innerText = numVencidos;
    document.getElementById('card-acabando').innerText = numAcabando;
    if(countNotifs > 0) document.getElementById('detalhes-notif-admin').open = true;

    window.estCardVencidos = numVencidos; window.estCardAcabando = numAcabando;

    if(chartInst1) chartInst1.destroy();
    chartInst1 = new Chart(document.getElementById('graficoEstoque').getContext('2d'), { type: 'bar', data: { labels: estoqueNomes, datasets: [{ label: 'Qtd Atual', data: estoqueQtd, backgroundColor: '#D32F2F', borderRadius: 4 }] }, options: { responsive: true } });
    renderGraficos();
};

window.renderGraficos = async () => {
    const filtro = document.getElementById('grafico-filtro').value;
    const now = new Date();
    
    const getDocsFiltered = async (col) => {
        let docsData = [];
        const snaps = await getDocs(collection(db, col));
        snaps.forEach(doc => {
            let d = doc.data();
            let date = new Date(d.timestamp);
            if(filtro === 'mes' && (date.getMonth() !== now.getMonth() || date.getFullYear() !== now.getFullYear())) return;
            if(filtro === 'ano' && date.getFullYear() !== now.getFullYear()) return;
            docsData.push(d);
        });
        return docsData;
    };

    const retiradas = await getDocsFiltered("retiradas");
    const avarias = await getDocsFiltered("avarias");

    let numReceitas = 0;
    retiradas.forEach(r => { if(r.tipo === 'receita') numReceitas += r.qtd; });
    document.getElementById('card-receitas').innerText = fmtQtd(numReceitas);
    window.estCardReceitas = fmtQtd(numReceitas);

    document.getElementById('card-avarias').innerText = avarias.length;
    window.estCardAvarias = avarias.length;

    let dadosObj = {};
    retiradas.forEach(r => { if(!dadosObj[r.nome]) dadosObj[r.nome] = {ret:0, ava:0}; dadosObj[r.nome].ret += r.qtd; });
    avarias.forEach(a => { if(!dadosObj[a.nome]) dadosObj[a.nome] = {ret:0, ava:0}; dadosObj[a.nome].ava += a.qtd; });

    const labels = Object.keys(dadosObj);
    const dRet = labels.map(l => fmtQtd(dadosObj[l].ret));
    const dAva = labels.map(l => fmtQtd(dadosObj[l].ava));

    if(chartInst2) chartInst2.destroy();
    chartInst2 = new Chart(document.getElementById('graficoComparacao').getContext('2d'), {
        type: 'bar',
        data: { labels, datasets: [ { label: 'Produção/Retirada', data: dRet, backgroundColor: '#1976d2' }, { label: 'Avarias/Perdas', data: dAva, backgroundColor: '#f57c00' } ] },
        options: { responsive: true, scales: { x: { stacked: false }, y: { stacked: false } } }
    });
};

window.gerarRelatorioPrint = async () => {
    const area = document.getElementById('print-area');
    
    // PDF totalmente remodelado, com formatação limpa e organizada
    let htmlContent = `
        <div style="font-family: Arial, sans-serif; padding: 20px; color: #333; max-width: 1000px; margin: 0 auto; background: #fff;">
            <div style="text-align:center; border-bottom: 3px solid #D32F2F; padding-bottom: 15px; margin-bottom: 25px;">
                <h1 style="color:#D32F2F; margin: 0; font-size: 26px; text-transform: uppercase;">Relatório Geral de Operações</h1>
                <p style="margin: 8px 0 0 0; font-size: 14px; color: #555;">Emitido em: ${new Date().toLocaleString('pt-BR')}</p>
            </div>
            
            <div style="display:flex; justify-content:space-around; background: #f4f6f8; padding: 20px; border-radius: 8px; border: 1px solid #ddd; margin-bottom: 30px;">
                <div style="text-align: center;">
                    <span style="display:block; font-size: 13px; font-weight: bold; color: #666; text-transform: uppercase;">Receitas Feitas</span>
                    <strong style="font-size: 22px; color: #1976d2;">${window.estCardReceitas||0}</strong>
                </div>
                <div style="text-align: center;">
                    <span style="display:block; font-size: 13px; font-weight: bold; color: #666; text-transform: uppercase;">Perdas/Avarias</span>
                    <strong style="font-size: 22px; color: #f57c00;">${window.estCardAvarias||0}</strong>
                </div>
                <div style="text-align: center;">
                    <span style="display:block; font-size: 13px; font-weight: bold; color: #666; text-transform: uppercase;">Produtos Vencidos</span>
                    <strong style="font-size: 22px; color: #d32f2f;">${window.estCardVencidos||0}</strong>
                </div>
                <div style="text-align: center;">
                    <span style="display:block; font-size: 13px; font-weight: bold; color: #666; text-transform: uppercase;">Estoque Acabando</span>
                    <strong style="font-size: 22px; color: #ff9800;">${window.estCardAcabando||0}</strong>
                </div>
            </div>
            
            <h3 style="color: #333; margin-bottom: 15px; font-size: 20px; border-bottom: 2px solid #eee; padding-bottom: 8px;">Posição Analítica de Estoque</h3>
            <table style="width:100%; border-collapse:collapse; font-size: 14px; margin-bottom: 30px;">
                <thead>
                    <tr style="background-color: #D32F2F; color: #ffffff; text-align: left;">
                        <th style="padding: 12px; border: 1px solid #ddd;">Item</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Lote</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Quantidade</th>
                        <th style="padding: 12px; border: 1px solid #ddd;">Vencimento</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    const snaps = await getDocs(collection(db, "insumos"));
    let cont = 0;
    snaps.forEach(s => {
        let d = s.data();
        let valFmt = d.validade ? new Date(d.validade).toLocaleDateString('pt-BR') : 'Sem validade';
        let bgLine = (cont % 2 === 0) ? '#f9f9f9' : '#ffffff';
        
        htmlContent += `<tr style="background-color: ${bgLine};">
            <td style="padding: 10px; border: 1px solid #ddd;"><strong>${d.nome}</strong></td>
            <td style="padding: 10px; border: 1px solid #ddd;">${d.lote||'-'}</td>
            <td style="padding: 10px; border: 1px solid #ddd; font-weight:bold;">${fmtQtd(d.qtd)} ${d.unidade||'un'}</td>
            <td style="padding: 10px; border: 1px solid #ddd;">${valFmt}</td>
        </tr>`;
        cont++;
    });
    
    htmlContent += `</tbody></table></div>`;
    area.innerHTML = htmlContent;
    
    area.style.display = 'block';
    window.print();
    area.style.display = 'none';
};

// ================= TELA: GESTÃO DE ESTOQUE =================
let insEditId = null;

window.renderInsumos = async () => {
    setActiveMenu('m-est');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-boxes"></i> Estoque</h2>
        <div class="card grid-3" style="background:var(--card-bg); border:1px solid var(--border-color);">
            <input type="text" id="ins-nome" placeholder="Nome do Insumo">
            
            <div style="display: flex; gap: 5px; align-items: center;">
                <input type="number" id="ins-qtd" placeholder="Qtd Atual" step="0.01" style="flex:1; margin:0;">
                <select id="ins-unidade" style="padding: 10px; border: 1px solid var(--border-color); border-radius: 4px; max-width: 90px; margin:0;">
                    <option value="un">un (Unidade)</option>
                    <option value="kg">kg (Kilo)</option>
                    <option value="g">g (Gramas)</option>
                    <option value="L">L (Litro)</option>
                    <option value="ml">ml (Mililitro)</option>
                    <option value="fatia">fatia</option>
                </select>
            </div>
            
            <input type="number" id="ins-min" placeholder="Estoque Mínimo" step="0.01">
            
            <div><label style="font-size:12px;">Validade:</label><input type="date" id="ins-val"></div>
            <div><label style="font-size:12px;">Lote (Opcional):</label><input type="text" id="ins-lote"></div>
            <div><label style="font-size:12px;">Fornecedor (Opcional):</label><input type="text" id="ins-forn"></div>
            <div style="grid-column: span 3; display:flex; gap:10px;">
                <button class="btn-primary" id="btn-salvar-ins" onclick="salvarInsumo()"><i class="fas fa-plus-circle"></i> Salvar Estoque</button>
                <button class="btn-secondary" id="btn-canc-ins" onclick="renderInsumos()" style="display:none;"><i class="fas fa-times"></i> Cancelar</button>
            </div>
        </div>
        <div class="card">
            <div class="search-box"><i class="fas fa-search"></i><input type="text" id="busca-ins-tabela" placeholder="Pesquisar estoque..." onkeyup="filtrarTabelaEstoque()"></div>
            <table id="tb-insumos">
                <thead><tr><th><i class="fas fa-box"></i> Insumo</th><th>Lote</th><th>Qtd</th><th>Mínimo</th><th>Fornecedor</th><th>Validade</th><th>Status</th><th>Ações</th></tr></thead>
                <tbody></tbody>
            </table>
        </div>
    `;
    insEditId = null; carregarTabelaEstoque();
};

window.filtrarTabelaEstoque = () => {
    const t = document.getElementById('busca-ins-tabela').value.toLowerCase();
    document.querySelectorAll('#tb-insumos tbody tr').forEach(r => {
        if(r.classList.contains('table-parent-row')) { r.style.display = r.innerText.toLowerCase().includes(t) ? '' : 'none'; }
        else if (r.classList.contains('table-child-row')) { r.classList.remove('open'); }
    });
};

window.salvarInsumo = async () => {
    const d = { 
        nome: document.getElementById('ins-nome').value, 
        unidade: document.getElementById('ins-unidade').value,
        qtd: fmtQtd(document.getElementById('ins-qtd').value), 
        min_qtd: fmtQtd(document.getElementById('ins-min').value), 
        validade: document.getElementById('ins-val').value, 
        lote: document.getElementById('ins-lote').value, 
        fornecedor: document.getElementById('ins-forn').value 
    };
    if(!d.nome || isNaN(d.qtd) || isNaN(d.min_qtd) || d.min_qtd < 0) return await customAlert("Preencha Nome e Qtds válidas (Mínimo >= 0).");
    
    let motivo = "Entrada/Atualização Inicial";
    if(insEditId) {
        motivo = await customPrompt("Motivo da edição:");
        if(!motivo) return await customAlert("Motivo é obrigatório para auditoria.");
        await updateDoc(doc(db, "insumos", insEditId), d); 
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Edição Insumo", d.nome, `Motivo: ${motivo}`);
    } else { 
        d.data_criacao = new Date().toISOString(); 
        await addDoc(collection(db, "insumos"), d); 
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Novo Insumo", d.nome, `Qtd: ${d.qtd} ${d.unidade}`);
    }
    renderInsumos();
};

window.carregarTabelaEstoque = async () => {
    const tbody = document.querySelector('#tb-insumos tbody'); tbody.innerHTML = "";
    const snaps = await getDocs(collection(db, "insumos"));
    let itemsGrouped = {};
    const hoje = new Date();

    snaps.forEach(s => {
        let d = s.data(); d.id = s.id;
        if(!itemsGrouped[d.nome]) itemsGrouped[d.nome] = [];
        itemsGrouped[d.nome].push(d);
    });

    Object.keys(itemsGrouped).forEach((nome, idx) => {
        const arr = itemsGrouped[nome];
        let totalQtd = arr.reduce((acc, curr) => acc + parseFloat(curr.qtd), 0);
        let uni = arr[0].unidade || 'un';
        
        if(arr.length === 1) {
            tbody.innerHTML += gerarLinhaInsumoHtml(arr[0], hoje, false);
        } else {
            tbody.innerHTML += `<tr class="table-parent-row">
                <td><button class="btn-expand" onclick="toggleRows('group-${idx}')"><i class="fas fa-plus-square"></i></button> <strong>${nome}</strong> (Vários Lotes)</td>
                <td>-</td><td><strong>${fmtQtd(totalQtd)} ${uni}</strong></td><td>-</td><td>-</td><td>-</td><td>-</td><td>-</td>
            </tr>`;
            arr.forEach(item => { tbody.innerHTML += gerarLinhaInsumoHtml(item, hoje, true, `group-${idx}`); });
        }
    });
};

window.toggleRows = (groupClass) => { document.querySelectorAll(`.child-${groupClass}`).forEach(el => el.classList.toggle('open')); };

function gerarLinhaInsumoHtml(d, hoje, isChild, groupClass = "") {
    let statusHTML = `<span class="badge" style="background:#4caf50;">OK</span>`;
    let valFmt = d.validade ? new Date(d.validade).toLocaleDateString('pt-BR') : '-';
    
    if (d.qtd < 0) {
        statusHTML = `<span class="badge" style="background:#000; color:#fff;">Estoque Negativo</span>`;
    } else if(d.validade) {
        let diffDias = Math.ceil((new Date(d.validade) - hoje) / (1000 * 60 * 60 * 24));
        if(diffDias < 0) statusHTML = `<span class="badge" style="background:#f44336;">Vencido</span>`;
        else if(diffDias <= 7) statusHTML = `<span class="badge" style="background:#ff9800;">Alerta (${diffDias}d)</span>`;
    }
    
    let corQtd = d.qtd < 0 ? 'red' : (d.qtd <= d.min_qtd ? '#ff9800' : 'inherit');

    return `<tr class="${isChild ? `table-child-row child-${groupClass}` : 'table-parent-row'}">
        <td style="${isChild?'padding-left:40px;':''}"><i class="fas fa-cube" style="color:#aaa;"></i> ${d.nome}</td>
        <td>${d.lote||'-'}</td>
        <td style="color:${corQtd}; font-weight: bold;">${fmtQtd(d.qtd)} ${d.unidade || 'un'}</td>
        <td>${fmtQtd(d.min_qtd)||0} ${d.unidade || 'un'}</td>
        <td>${d.fornecedor||'-'}</td>
        <td>${valFmt}</td>
        <td>${statusHTML}</td>
        <td style="white-space:nowrap;">
            <button class="btn-icon edit" onclick="editarInsumoUI('${d.id}')" title="Editar"><i class="fas fa-edit"></i></button>
            <button class="btn-icon undo" onclick="apagarInsumo('${d.id}', '${d.nome}')" title="Excluir"><i class="fas fa-trash"></i></button>
        </td>
    </tr>`;
}

window.editarInsumoUI = async (id) => {
    const d = (await getDoc(doc(db, "insumos", id))).data();
    document.getElementById('ins-nome').value = d.nome; 
    document.getElementById('ins-unidade').value = d.unidade || 'un';
    document.getElementById('ins-qtd').value = d.qtd; 
    document.getElementById('ins-min').value = d.min_qtd; 
    document.getElementById('ins-val').value = d.validade; 
    document.getElementById('ins-lote').value = d.lote; 
    document.getElementById('ins-forn').value = d.fornecedor;
    
    insEditId = id;
    document.getElementById('btn-salvar-ins').innerHTML = '<i class="fas fa-save"></i> Atualizar'; 
    document.getElementById('btn-canc-ins').style.display = 'flex';
    window.scrollTo(0,0);
};

window.apagarInsumo = async (id, nome) => {
    let motivo = await customPrompt(`Tem certeza que deseja excluir '${nome}'? Motivo:`);
    if(!motivo) return await customAlert("Exclusão cancelada (Motivo não informado).");
    await deleteDoc(doc(db, "insumos", id));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Exclusão Insumo", nome, `Motivo: ${motivo}`);
    renderInsumos();
};

// ================= TELA: FICHA TÉCNICA (RECEITAS) =================
let recEditId = null, ingTemp = [], recUrlImg = "";

window.renderReceitas = async () => {
    setActiveMenu('m-rec');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-hamburger"></i> Receitas</h2>
        
        <div class="search-box" style="margin-bottom: 20px;"><i class="fas fa-search"></i><input type="text" id="busca-rec-galeria" placeholder="Pesquisar receitas prontas..." onkeyup="filtrarGaleriaReceitas()"></div>

        <div class="card grid-2" style="background:var(--card-bg); border:1px solid var(--border-color);">
            <div style="display:flex; flex-direction:column; gap:10px;">
                <input type="text" id="rec-nome" placeholder="Nome da Receita/Lanche">
                <label class="custom-file-upload">
                    <i class="fas fa-upload"></i> Escolher Imagem (Salva localmente)
                    <input type="file" id="rec-foto" accept="image/png, image/jpeg" onchange="atualizarFotoReceita(this, 'preview-foto')">
                </label>
                <img id="preview-foto" style="max-height:100px; display:none; border-radius:8px; align-self:center;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3075/3075977.png'">
            </div>
            <div>
                <label style="font-size:12px;">Ingredientes:</label>
                <div class="custom-list" id="lista-ing-add" style="max-height:120px;"></div>
                <div style="display: flex; gap: 5px; align-items: center; margin-bottom: 5px;">
                    <input type="number" id="rec-ing-qtd" placeholder="Qtd na Receita" step="0.01" style="flex:1; margin:0;">
                    <select id="rec-ing-unidade" style="padding: 10px; border: 1px solid var(--border-color); border-radius: 4px; max-width: 100px; margin:0;">
                        <option value="un">un</option>
                    </select>
                </div>
                <button class="btn-secondary" onclick="addIngRec()"><i class="fas fa-plus"></i> Adicionar Ingrediente</button>
            </div>
            <div style="grid-column: span 2;">
                <ul id="lista-ing-temp" style="background:var(--bg); padding:10px; border-radius:8px; list-style:none;"><i>Nenhum ingrediente.</i></ul>
                <div style="display:flex; gap:10px; margin-top:10px;">
                    <button class="btn-primary" id="btn-salvar-rec" onclick="salvarRec()"><i class="fas fa-save"></i> Salvar Receita</button>
                    <button class="btn-secondary" onclick="renderReceitas()"><i class="fas fa-times"></i> Cancelar</button>
                </div>
            </div>
        </div>
        <div class="grid-3" id="galeria-receitas"></div>
    `;
    recEditId = null; ingTemp = []; recUrlImg = "";
    carregarInsumosRadios(); carregarGaleriaReceitas();
};

window.filtrarGaleriaReceitas = () => {
    const t = document.getElementById('busca-rec-galeria').value.toLowerCase();
    document.querySelectorAll('#galeria-receitas .card').forEach(card => {
        const nome = card.querySelector('h3').innerText.toLowerCase();
        card.style.display = nome.includes(t) ? '' : 'none';
    });
};

window.carregarInsumosRadios = async () => {
    const div = document.getElementById('lista-ing-add'); div.innerHTML = "";
    const snaps = await getDocs(collection(db, "insumos"));
    snaps.forEach(docSnap => {
        let d = docSnap.data();
        div.innerHTML += `<div class="custom-list-item">
            <input type="radio" name="radio-add-ing" id="r-${docSnap.id}" value="${docSnap.id}" data-unidade="${d.unidade||'un'}" onchange="atualizarOpcoesUnidadeReceita('${d.unidade||'un'}')">
            <label for="r-${docSnap.id}"><strong>${d.nome}</strong> (Lote: ${d.lote||'N/A'}) - Estoque: ${d.unidade||'un'}</label>
        </div>`;
    });
};

window.addIngRec = async () => {
    const sel = document.querySelector('input[name="radio-add-ing"]:checked'); 
    const qtd = document.getElementById('rec-ing-qtd').value;
    const unRec = document.getElementById('rec-ing-unidade').value;
    if(!sel || !qtd) return await customAlert("Selecione ingrediente e quantidade.");
    
    const docSnap = await getDoc(doc(db, "insumos", sel.value));
    const d = docSnap.data();
    ingTemp.push({ insumoId: sel.value, nome: d.nome, qtd: fmtQtd(qtd), unidade_receita: unRec, unidade_estoque: d.unidade || 'un' });
    atualizarUITemp();
};

window.atualizarUITemp = () => {
    const l = document.getElementById('lista-ing-temp'); l.innerHTML = "";
    if(ingTemp.length===0) return l.innerHTML = "<i>Nenhum ingrediente.</i>";
    ingTemp.forEach((i, idx) => {
        l.innerHTML += `<li style="margin-bottom:5px; display:flex; justify-content:space-between; border-bottom:1px solid var(--border-color); padding-bottom:5px;">
            <span><i class="fas fa-utensil-spoon"></i> ${i.nome}: <strong>${fmtQtd(i.qtd)} ${i.unidade_receita || i.unidade_estoque}</strong> <span style="font-size:10px; opacity:0.7;">(Baixa no estoque em ${i.unidade_estoque})</span></span>
            <button class="btn-icon undo" style="padding:4px;" onclick="removerIngTemp(${idx})"><i class="fas fa-trash"></i></button>
        </li>`;
    });
};
window.removerIngTemp = (idx) => { ingTemp.splice(idx, 1); atualizarUITemp(); };

window.salvarRec = async () => {
    const nome = document.getElementById('rec-nome').value;
    if(!nome || ingTemp.length===0) return await customAlert("Nome e ingredientes obrigatórios.");
    const d = { nome, foto_url: recUrlImg, ingredientes: ingTemp };
    if(recEditId) {
        let motivo = await customPrompt("Motivo da alteração da receita:");
        if(!motivo) return await customAlert("Cancelado.");
        await updateDoc(doc(db, "receitas", recEditId), d);
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Edição Receita", nome, `Motivo: ${motivo}`);
    } else { 
        await addDoc(collection(db, "receitas"), d); 
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Nova Receita", nome, "");
    }
    renderReceitas();
};

window.carregarGaleriaReceitas = async () => {
    const g = document.getElementById('galeria-receitas');
    const s = await getDocs(collection(db, "receitas"));
    s.forEach(dSnap => {
        const d = dSnap.data();
        let ings = d.ingredientes.map(i => `${i.nome}(${fmtQtd(i.qtd)} ${i.unidade_receita || i.unidade_estoque})`).join(', ');
        g.innerHTML += `
            <div class="card" style="display:flex; flex-direction:column; justify-content:space-between;">
                <div>
                    ${d.foto_url ? `<img src="${d.foto_url}" style="width:100%; height:150px; object-fit:cover; border-radius:8px;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3075/3075977.png'">` : '<div style="height:150px; background:var(--bg); display:flex; align-items:center; justify-content:center; border-radius:8px;"><i class="fas fa-hamburger fa-2x" style="color:#ccc;"></i></div>'}
                    <h3 style="margin-top:10px;"><i class="fas fa-hashtag"></i> ${d.nome}</h3><p style="font-size:12px; opacity:0.7; margin-top:5px;">${ings}</p>
                </div>
                <div style="display:flex; gap:10px; margin-top:15px;">
                    <button class="btn-icon edit" onclick="editarRecUI('${dSnap.id}')" title="Editar"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon undo" onclick="apagarReceita('${dSnap.id}', '${d.nome}')" title="Excluir"><i class="fas fa-trash"></i></button>
                </div>
            </div>`;
    });
};

window.editarRecUI = async (id) => {
    const d = (await getDoc(doc(db, "receitas", id))).data();
    document.getElementById('rec-nome').value = d.nome; ingTemp = d.ingredientes; atualizarUITemp();
    if(d.foto_url) { recUrlImg = d.foto_url; document.getElementById('preview-foto').src = d.foto_url; document.getElementById('preview-foto').style.display='block'; }
    recEditId = id; window.scrollTo(0,0);
};

window.apagarReceita = async (id, nome) => {
    let motivo = await customPrompt(`Motivo para excluir a receita '${nome}':`);
    if(!motivo) return;
    await deleteDoc(doc(db, "receitas", id));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Exclusão Receita", nome, `Motivo: ${motivo}`);
    renderReceitas();
};

// ================= TELA: EQUIPE & AUDITORIA =================
window.renderEquipe = async () => {
    setActiveMenu('m-eq');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-users"></i> Equipe</h2>
        <div class="card"><table id="tb-equipe"><tr><th>Funcionário</th><th>E-mail</th><th>Logs</th><th>Ações</th></tr></table></div>
    `;
    const tb = document.getElementById('tb-equipe');
    const snaps = await getDocs(query(collection(db, "users"), where("role", "==", "operacional")));
    snaps.forEach(docSnap => {
        const d = docSnap.data();
        const plainEmail = safeDecrypt(d.email);
        tb.innerHTML += `<tr>
            <td><div style="display:flex; align-items:center; gap:10px;"><img src="${d.foto_url||'https://cdn-icons-png.flaticon.com/512/149/149071.png'}" style="width:30px;height:30px;border-radius:50%;object-fit:cover;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/149/149071.png'"> <strong>${safeDecrypt(d.nome)}</strong></div></td>
            <td>${plainEmail}</td>
            <td><button class="btn-secondary" style="padding:5px 10px; width:auto; font-size:12px;" onclick="renderAuditoria('${plainEmail}')"><i class="fas fa-search"></i> Ver Histórico</button></td>
            <td><button class="btn-icon undo" onclick="apagarAcesso('${plainEmail}')" title="Remover Acesso"><i class="fas fa-user-times"></i></button></td>
        </tr>`;
    });
};

window.apagarAcesso = async (emailPlain) => {
    let m = await customPrompt("Motivo para remover este usuário:");
    if(!m) return;
    await deleteDoc(doc(db, "users", emailPlain));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Deletar Usuário", emailPlain, `Motivo: ${m}`);
    renderEquipe();
};

window.renderAuditoria = async (filtroEmail = null) => {
    setActiveMenu('m-log');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-shield-alt"></i> Histórico</h2>
        <div class="card grid-2" style="background:var(--card-bg);">
            <div><label>Filtro por Usuário (E-mail):</label><input type="text" id="busca-log-email" onkeyup="filtrarLogs()"></div>
            <div style="display:flex; gap:10px;">
                <div style="flex:1;"><label>De:</label><input type="date" id="log-data-ini" onchange="filtrarLogs()"></div>
                <div style="flex:1;"><label>Até:</label><input type="date" id="log-data-fim" onchange="filtrarLogs()"></div>
            </div>
        </div>
        <div class="card"><table id="tb-logs"><thead><tr><th>Data/Hora</th><th>Usuário</th><th>Ação</th><th>Detalhes</th></tr></thead><tbody></tbody></table></div>`;
    
    if(typeof filtroEmail === 'string' && filtroEmail.trim() !== '') {
        document.getElementById('busca-log-email').value = filtroEmail;
    }

    const snaps = await getDocs(query(collection(db, "logs"), orderBy("timestamp", "desc")));
    window.allLogs = [];
    snaps.forEach(s => {
        let dataLog = s.data();
        dataLog.userEmailDecrypted = safeDecrypt(dataLog.userEmail);
        dataLog.userNameDecrypted = safeDecrypt(dataLog.userName);
        dataLog.actionDecrypted = safeDecrypt(dataLog.action);
        dataLog.itemDecrypted = safeDecrypt(dataLog.item);
        dataLog.detailsDecrypted = safeDecrypt(dataLog.details);
        window.allLogs.push(dataLog);
    });
    filtrarLogs();
};

window.filtrarLogs = () => {
    const tbody = document.querySelector('#tb-logs tbody'); tbody.innerHTML = "";
    const emailFilter = document.getElementById('busca-log-email') ? document.getElementById('busca-log-email').value.toLowerCase() : '';
    const dIni = document.getElementById('log-data-ini') ? document.getElementById('log-data-ini').value : '';
    const dFim = document.getElementById('log-data-fim') ? document.getElementById('log-data-fim').value : '';

    let filtrados = window.allLogs.filter(d => {
        if(emailFilter && !d.userEmailDecrypted.toLowerCase().includes(emailFilter)) return false;
        let ts = new Date(d.timestamp); ts.setHours(0,0,0,0);
        if(dIni && ts < new Date(dIni+"T00:00:00")) return false;
        if(dFim && ts > new Date(dFim+"T23:59:59")) return false;
        return true;
    });

    filtrados.forEach(d => { 
        tbody.innerHTML += `<tr><td>${new Date(d.timestamp).toLocaleString('pt-BR')}</td>
        <td><strong>${d.userNameDecrypted}</strong><br><span style="font-size:11px;opacity:0.7;">${d.userEmailDecrypted}</span></td>
        <td><span class="badge" style="background:#555;">${d.actionDecrypted}</span></td>
        <td><strong>${d.itemDecrypted}</strong><br><span style="font-size:12px;">${d.detailsDecrypted}</span></td></tr>`; 
    });
};

// ================= TELA: OPERACIONAL - DASH/BAIXAS =================
window.renderBaixas = async () => {
    setActiveMenu('m-bax');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-bolt"></i> Produção</h2>
        
        <details id="detalhes-notif-op" style="margin-bottom:20px; background:var(--card-bg); padding:10px; border:1px solid var(--border-color); border-radius:8px;">
            <summary style="font-weight:bold; cursor:pointer; color:#b71c1c;"><i class="fas fa-bell"></i> Notificações (<span id="op-notif-count">0</span>)</summary>
            <div id="op-alerts" class="grid-2" style="margin-top:10px;"></div>
        </details>

        <div class="grid-2">
            <div class="card">
                <h3><i class="fas fa-box-open"></i> Baixa Avulsa (Insumos)</h3>
                <div class="search-box"><i class="fas fa-search"></i><input type="text" id="busca-ins-rapido" placeholder="Buscar insumo..." onkeyup="filtrarListaRadio('busca-ins-rapido', 'lista-insumos-rapido')"></div>
                <div class="custom-list" id="lista-insumos-rapido"></div>
                <div style="display:flex; gap:5px; align-items:center;">
                    <input type="number" id="qtd-baixa-rapida" placeholder="Quantidade" step="0.01" style="flex:1; margin:0;">
                    <select id="un-baixa-rapida" style="padding:10px; border:1px solid var(--border-color); border-radius:4px; max-width:110px; margin:0;"><option value="">-</option></select>
                </div>
                <button class="btn-primary" style="margin-top:10px;" onclick="salvarBaixaRapida()"><i class="fas fa-minus-circle"></i> Registrar Retirada</button>
                
                <h4 style="margin-top:25px; border-top:1px solid var(--border-color); padding-top:15px;"><i class="fas fa-history"></i> Últimas Retiradas</h4>
                <table id="tb-ret-man"><tr><th>Item</th><th>Data/Hora</th><th>Qtd</th><th>Ação</th></tr></table>
            </div>

            <div class="card">
                <h3><i class="fas fa-hamburger"></i> Produção de Receitas</h3>
                <div class="search-box"><i class="fas fa-search"></i><input type="text" id="busca-rec-rapido" placeholder="Buscar receita..." onkeyup="filtrarListaRadio('busca-rec-rapido', 'lista-receitas-rapido')"></div>
                <div class="custom-list" id="lista-receitas-rapido" style="display:grid; grid-template-columns:1fr 1fr; gap:10px; padding:10px;"></div>
                <input type="number" id="qtd-baixa-receita" placeholder="Qtd Produzida" min="1" step="1" value="1">
                <button class="btn-primary" style="background:#ff9800" onclick="salvarBaixaReceita()"><i class="fas fa-utensils"></i> Confirmar Produção</button>

                <h4 style="margin-top:25px; border-top:1px solid var(--border-color); padding-top:15px;"><i class="fas fa-history"></i> Últimas Produções</h4>
                <table id="tb-ret-rec"><tr><th>Receita</th><th>Data/Hora</th><th>Qtd</th><th>Ação</th></tr></table>
            </div>
        </div>

        <div class="card" style="margin-top: 20px;">
            <h3><i class="fas fa-clipboard-list"></i> Situação Geral de Insumos</h3>
            <div class="search-box"><i class="fas fa-search"></i><input type="text" id="busca-resumo-est" placeholder="Pesquisar estoque..." onkeyup="filtrarResumoEstoque()"></div>
            <table id="tb-resumo-est">
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Lote</th>
                        <th>Status Qtd</th>
                        <th>Vencimento</th>
                        <th>Dias Restantes</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    `;
    
    const hoje = new Date();
    const snapsIns = await getDocs(collection(db, "insumos"));
    let strAlerts = "";
    let tbResumo = document.querySelector('#tb-resumo-est tbody');
    tbResumo.innerHTML = "";
    let opCount = 0;

    snapsIns.forEach(s => {
        let d = s.data();
        let avisoEstoque = `<span class="badge" style="background:#4caf50;">Resta ${fmtQtd(d.qtd)} ${d.unidade||'un'}</span>`;
        let avisoVencimento = "-";
        let diasStr = "-";
        
        if (d.qtd < 0) {
            strAlerts += `<div class="alert-box alert-danger" style="background: rgba(183, 28, 28, 0.1); border-color: #b71c1c;"><i class="fas fa-ban" style="color: #b71c1c;"></i> <div><strong style="color: #b71c1c;">ESTOQUE INCORRETO (NEGATIVO):</strong> ${d.nome} consta saldo de ${fmtQtd(d.qtd)} ${d.unidade||'un'}. Cuidado e ajuste!</div></div>`;
            avisoEstoque = `<span class="badge" style="background:#000; color:#fff;">Incorreto (${fmtQtd(d.qtd)} ${d.unidade||'un'})</span>`;
            opCount++;
        } else if (d.qtd === 0) {
            strAlerts += `<div class="alert-box alert-danger"><i class="fas fa-ban"></i> <div><strong>Falta no Estoque:</strong> ${d.nome} acabou! Impede uso.</div></div>`;
            avisoEstoque = `<span class="badge" style="background:#f44336;">Acabou! (0 ${d.unidade||'un'})</span>`;
            opCount++;
        } else if (d.qtd <= d.min_qtd) {
            avisoEstoque = `<span class="badge" style="background:#ff9800;">Acabando (Resta ${fmtQtd(d.qtd)} ${d.unidade||'un'})</span>`;
            strAlerts += `<div class="alert-box alert-warning"><i class="fas fa-exclamation-triangle"></i> <div><strong>Estoque Baixo:</strong> ${d.nome} restam apenas ${fmtQtd(d.qtd)} ${d.unidade||'un'}.</div></div>`;
            opCount++;
        }
        
        if(d.validade) {
            avisoVencimento = new Date(d.validade).toLocaleDateString('pt-BR');
            let dias = Math.ceil((new Date(d.validade) - hoje) / (1000 * 60 * 60 * 24));
            if(dias < 0) {
                strAlerts += `<div class="alert-box alert-danger"><i class="fas fa-skull-crossbones"></i> <div><strong>PRODUTO VENCIDO:</strong> Não utilize ${d.nome} (Lote: ${d.lote||'-'})!</div></div>`;
                diasStr = `<span style="color:#f44336; font-weight:bold;">Vencido!</span>`;
                opCount++;
            } else if (dias <= 7) {
                diasStr = `<span style="color:#ff9800; font-weight:bold;">Vence em ${dias} dias</span>`;
                strAlerts += `<div class="alert-box alert-warning"><i class="fas fa-calendar-times"></i> <div><strong>Vencimento próximo:</strong> ${d.nome} (Lote: ${d.lote||'-'}) vence em ${dias} dias.</div></div>`;
                opCount++;
            } else {
                diasStr = `${dias} dias`;
            }
        }
        
        tbResumo.innerHTML += `<tr class="resumo-row">
            <td><strong>${d.nome}</strong></td>
            <td>${d.lote||'-'}</td>
            <td>${avisoEstoque}</td>
            <td>${avisoVencimento}</td>
            <td>${diasStr}</td>
        </tr>`;
    });
    
    document.getElementById('op-alerts').innerHTML = strAlerts || "<i>Nenhuma notificação no momento.</i>";
    document.getElementById('op-notif-count').innerText = opCount;
    // Abre aba de alertas automaticamente se houver algo crítico
    if (opCount > 0) {
        document.getElementById('detalhes-notif-op').open = true;
    }

    carregarListasBaixa(); carregarHistoricoBaixas();
};

window.filtrarResumoEstoque = () => {
    const t = document.getElementById('busca-resumo-est').value.toLowerCase();
    document.querySelectorAll('.resumo-row').forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(t) ? '' : 'none';
    });
};

window.filtrarListaRadio = (inputId, listId) => {
    const termo = document.getElementById(inputId).value.toLowerCase();
    document.querySelectorAll(`#${listId} .custom-list-item`).forEach(el => { el.style.display = el.innerText.toLowerCase().includes(termo) ? '' : 'none'; });
};

window.carregarListasBaixa = async () => {
    const divIns = document.getElementById('lista-insumos-rapido'); divIns.innerHTML = "";
    const divRec = document.getElementById('lista-receitas-rapido'); divRec.innerHTML = "";
    const hoje = new Date();

    const sIns = await getDocs(collection(db, "insumos"));
    sIns.forEach(doc => {
        let d = doc.data();
        let valWarn = "";
        if(d.validade && (new Date(d.validade) < hoje)) valWarn = `<span style="color:red; font-size:10px; font-weight:bold;">(VENCIDO)</span>`;
        // Vincula a restrição do input ao clicar no insumo
        divIns.innerHTML += `<div class="custom-list-item"><input type="radio" name="r-ins-bx" id="bxi-${doc.id}" value="${doc.id}" onchange="atualizarOpcoesUnidadeUI('un-baixa-rapida', '${d.unidade||'un'}')">
            <label for="bxi-${doc.id}"><strong>${d.nome}</strong> ${valWarn}<br><span style="font-size:11px; opacity:0.7;">Lote: ${d.lote||'-'} | Resta: ${fmtQtd(d.qtd)} ${d.unidade||'un'}</span></label></div>`;
    });

    const sRec = await getDocs(collection(db, "receitas"));
    sRec.forEach(doc => {
        let d = doc.data();
        divRec.innerHTML += `<div class="custom-list-item" style="flex-direction:column; text-align:center; padding:10px; border:1px solid var(--border-color); border-radius:8px;">
            <input type="radio" name="r-rec-bx" id="bxr-${doc.id}" value="${doc.id}" style="margin:0 0 10px 0;">
            <label for="bxr-${doc.id}">
                ${d.foto_url ? `<img src="${d.foto_url}" style="width:100%; height:70px; object-fit:cover; border-radius:4px; margin-bottom:5px;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3075/3075977.png'">` : '<i class="fas fa-hamburger fa-2x" style="color:#ccc; display:block; margin-bottom:5px;"></i>'}
                <strong>${d.nome}</strong>
            </label>
        </div>`;
    });
};

window.salvarBaixaRapida = async () => {
    const sel = document.querySelector('input[name="r-ins-bx"]:checked');
    const qtdDigitada = parseFloat(document.getElementById('qtd-baixa-rapida').value);
    const unSelecionada = document.getElementById('un-baixa-rapida').value;
    
    if(!sel || isNaN(qtdDigitada) || !unSelecionada) return await customAlert("Selecione um ingrediente e informe a quantidade na caixa de medidas.");
    
    const iRef = doc(db, "insumos", sel.value);
    const iDoc = await getDoc(iRef);
    let d = iDoc.data();
    
    // Converte e arredonda a quantidade escolhida para abater corretamente da unidade do sistema
    let qtdRealParaBaixar = converterUnidade(qtdDigitada, unSelecionada, d.unidade);
    qtdRealParaBaixar = parseFloat(qtdRealParaBaixar.toFixed(3));
    
    if(d.qtd <= 0) return await customAlert(`BLOQUEIO DE SISTEMA: O estoque de ${d.nome} está zerado ou negativo! Nenhuma retirada é permitida.`);
    if(qtdRealParaBaixar > d.qtd) return await customAlert(`BLOQUEIO DE SISTEMA: Você tentou retirar ${fmtQtd(qtdRealParaBaixar)} ${d.unidade||'un'}, mas só existem ${fmtQtd(d.qtd)} ${d.unidade||'un'} no estoque.`);
    
    if(d.validade && new Date(d.validade) < new Date()) {
        let conf = await customConfirm(`⚠️ ALERTA: ${d.nome} está VENCIDO! Deseja registrar a baixa assumindo o risco?`);
        if(!conf) return;
    }

    let novoSaldo = parseFloat((d.qtd - qtdRealParaBaixar).toFixed(3));

    await updateDoc(iRef, { qtd: novoSaldo });
    await addDoc(collection(db, "retiradas"), { 
        insumoId: sel.value, 
        nome: d.nome, 
        qtd: qtdRealParaBaixar, // Salva na base formatado na unidade matriz
        unidade: d.unidade||'un', 
        tipo: 'manual', 
        userUid: currentAuthUser.uid, 
        userEmail: window.encrypt(currentUserData.email_plain), 
        timestamp: new Date().toISOString() 
    });
    
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Retirada Insumo", d.nome, `Qtd Retirada: ${qtdDigitada} ${unSelecionada} (Convertido: ${fmtQtd(qtdRealParaBaixar)} ${d.unidade})`);
    renderBaixas();
};

window.salvarBaixaReceita = async () => {
    const sel = document.querySelector('input[name="r-rec-bx"]:checked');
    const qtdProd = parseFloat(document.getElementById('qtd-baixa-receita').value);
    if(!sel || !qtdProd) return await customAlert("Selecione a receita e a quantidade.");
    
    const recDoc = await getDoc(doc(db, "receitas", sel.value));
    const ings = recDoc.data().ingredientes;
    const urlFotoRec = recDoc.data().foto_url || "";
    
    for (const ing of ings) {
        const iDoc = await getDoc(doc(db, "insumos", ing.insumoId));
        if(!iDoc.exists()) return await customAlert(`Insumo deletado do banco: ${ing.nome}`);
        let d = iDoc.data();
        
        let qtdIngNecessariaConvertida = converterUnidade(ing.qtd * qtdProd, ing.unidade_receita || ing.unidade_estoque, d.unidade);
        qtdIngNecessariaConvertida = parseFloat(qtdIngNecessariaConvertida.toFixed(3));

        if(d.qtd <= 0) return await customAlert(`BLOQUEIO: Produção barrada pois o estoque de ${d.nome} está completamente zerado ou negativo.`);
        if(d.qtd < qtdIngNecessariaConvertida) return await customAlert(`BLOQUEIO: Faltam ${(qtdIngNecessariaConvertida - d.qtd).toFixed(3)} ${d.unidade||'un'} de ${d.nome} para esta produção.`);
        
        if(d.validade && new Date(d.validade) < new Date()) { 
            let conf = await customConfirm(`⚠️ ATENÇÃO: O ingrediente ${d.nome} está vencido! Tem certeza que deseja dar continuidade na produção?`);
            if(!conf) return; 
        }
    }
    
    for (const ing of ings) {
        const iRef = doc(db, "insumos", ing.insumoId);
        const iDoc = await getDoc(iRef);
        let d = iDoc.data();
        let qtdIngNecessariaConvertida = converterUnidade(ing.qtd * qtdProd, ing.unidade_receita || ing.unidade_estoque, d.unidade);
        qtdIngNecessariaConvertida = parseFloat(qtdIngNecessariaConvertida.toFixed(3));
        
        await updateDoc(iRef, { qtd: parseFloat((d.qtd - qtdIngNecessariaConvertida).toFixed(3)) });
    }
    
    await addDoc(collection(db, "retiradas"), { receitaId: sel.value, nome: recDoc.data().nome, foto_url: urlFotoRec, qtd: qtdProd, ingredientes: ings, tipo: 'receita', userUid: currentAuthUser.uid, userEmail: window.encrypt(currentUserData.email_plain), timestamp: new Date().toISOString() });
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Produção Receita", recDoc.data().nome, `Qtd Produzida: ${qtdProd}`);
    renderBaixas();
};

window.carregarHistoricoBaixas = async () => {
    const snaps = await getDocs(query(collection(db, "retiradas"), where("userUid", "==", currentAuthUser.uid)));
    const tbMan = document.getElementById('tb-ret-man'); const tbRec = document.getElementById('tb-ret-rec');
    
    snaps.forEach(docSnap => {
        const d = docSnap.data();
        
        // Formata a data e hora
        const dataHoraFormatada = new Date(d.timestamp).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

        if (d.tipo === 'manual') {
            tbMan.innerHTML += `<tr>
                <td>${d.nome}</td>
                <td>${dataHoraFormatada}</td>
                <td>${fmtQtd(d.qtd)} ${d.unidade||''}</td>
                <td style="white-space:nowrap;">
                    <button class="btn-icon edit" onclick="editarRetiradaMan('${docSnap.id}', '${d.insumoId}', ${d.qtd})" title="Editar (Inserir direto na Medida Base)"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon undo" onclick="estornarBaixaMan('${docSnap.id}', '${d.insumoId}', ${d.qtd}, '${d.nome}')" title="Excluir/Estornar"><i class="fas fa-undo"></i></button>
                </td>
            </tr>`;
        } else if (d.tipo === 'receita') {
            const miniatura = d.foto_url ? `<img src="${d.foto_url}" style="width:40px;height:40px;object-fit:cover;border-radius:4px;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3075/3075977.png'">` : `<i class="fas fa-hamburger" style="color:#aaa; font-size: 24px;"></i>`;
            let listaIngredientes = d.ingredientes.map(i => `${i.nome} (${fmtQtd(i.qtd * d.qtd)} ${i.unidade_receita || i.unidade_estoque})`).join(', ');
            
            tbRec.innerHTML += `<tr>
                <td>
                    <div style="display:flex; align-items:center; gap:10px;">
                        ${miniatura} 
                        <div>
                            <strong>${d.nome}</strong><br>
                            <span style="font-size: 11px; color: #666;"><i class="fas fa-info-circle"></i> Usou: ${listaIngredientes}</span>
                        </div>
                    </div>
                </td>
                <td>${dataHoraFormatada}</td>
                <td style="font-weight:bold; color:var(--primary); font-size:16px;">${d.qtd}</td>
                <td style="white-space:nowrap;">
                    <button class="btn-icon edit" onclick="editarRetiradaRec('${docSnap.id}', ${JSON.stringify(d.ingredientes).replace(/"/g, '&quot;')}, ${d.qtd}, '${d.nome}')" title="Editar Qtd Produzida"><i class="fas fa-edit"></i></button>
                    <button class="btn-icon undo" onclick="estornarBaixaRec('${docSnap.id}', ${JSON.stringify(d.ingredientes).replace(/"/g, '&quot;')}, ${d.qtd}, '${d.nome}')" title="Desfazer/Devolver ao Estoque"><i class="fas fa-undo"></i></button>
                </td>
            </tr>`;
        }
    });
};

window.estornarBaixaMan = async (retId, insId, qtd, nome) => {
    let motivo = await customPrompt(`Motivo do estorno de ${fmtQtd(qtd)} ${nome}?`);
    if(!motivo) return;
    const iRef = doc(db, "insumos", insId); const iDoc = await getDoc(iRef);
    if(iDoc.exists()) await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd + parseFloat(qtd)).toFixed(3)) });
    await deleteDoc(doc(db, "retiradas", retId));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Estorno Baixa", nome, `Motivo: ${motivo}`);
    renderBaixas();
};

window.estornarBaixaRec = async (retId, ings, qtdProd, nome) => {
    let motivo = await customPrompt(`Motivo do cancelamento da produção de ${qtdProd}x ${nome}?`);
    if(!motivo) return;
    for (const ing of ings) {
        const iRef = doc(db, "insumos", ing.insumoId); const iDoc = await getDoc(iRef);
        if(iDoc.exists()){
            let qtdIngNecessariaConvertida = converterUnidade(ing.qtd * qtdProd, ing.unidade_receita || ing.unidade_estoque, iDoc.data().unidade);
            await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd + qtdIngNecessariaConvertida).toFixed(3)) });
        }
    }
    await deleteDoc(doc(db, "retiradas", retId));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Estorno Produção", nome, `Motivo: ${motivo}`);
    renderBaixas();
};

window.editarRetiradaMan = async (retId, insId, qtdAntiga) => {
    const novaQtd = await customPrompt("Corrija a quantidade real retirada (na mesma unidade do banco):", fmtQtd(qtdAntiga));
    if(!novaQtd || parseFloat(novaQtd) === parseFloat(qtdAntiga)) return;
    let motivo = await customPrompt("Motivo da alteração:"); if(!motivo) return;
    
    const diferenca = parseFloat(novaQtd) - parseFloat(qtdAntiga); 
    const iRef = doc(db, "insumos", insId); const iDoc = await getDoc(iRef);
    
    if(iDoc.exists() && iDoc.data().qtd >= diferenca) {
        await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd - diferenca).toFixed(3)) });
        await updateDoc(doc(db, "retiradas", retId), { qtd: parseFloat(novaQtd) });
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Edição Baixa", iDoc.data().nome, `Qtd ajustada de ${fmtQtd(qtdAntiga)} para ${fmtQtd(novaQtd)}. Motivo: ${motivo}`);
        renderBaixas();
    } else await customAlert("Estoque insuficiente para essa edição.");
};

window.editarRetiradaRec = async (retId, ings, qtdAntiga, nomeRec) => {
    const novaQtd = await customPrompt("Nova quantidade produzida da receita:", qtdAntiga);
    if(!novaQtd || parseFloat(novaQtd) === parseFloat(qtdAntiga)) return;
    let m = await customPrompt("Motivo da alteração:"); if(!m) return;
    
    const dif = parseFloat(novaQtd) - parseFloat(qtdAntiga);
    for (const ing of ings) {
        const iDoc = await getDoc(doc(db, "insumos", ing.insumoId));
        let difConvertida = converterUnidade(ing.qtd * dif, ing.unidade_receita || ing.unidade_estoque, iDoc.data().unidade);
        if(dif > 0 && (!iDoc.exists() || iDoc.data().qtd < difConvertida)) return await customAlert(`Estoque insuficiente de ${ing.nome} para produzir essa quantia extra.`);
    }
    for (const ing of ings) {
        const iRef = doc(db, "insumos", ing.insumoId); const iDoc = await getDoc(iRef);
        let difConvertida = converterUnidade(ing.qtd * dif, ing.unidade_receita || ing.unidade_estoque, iDoc.data().unidade);
        await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd - difConvertida).toFixed(3)) });
    }
    await updateDoc(doc(db, "retiradas", retId), { qtd: parseFloat(novaQtd) });
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Edição Produção", nomeRec, `Ajuste Qtd de ${qtdAntiga} para ${novaQtd}. Motivo: ${m}`);
    renderBaixas();
};

// ================= TELA: OPERACIONAL - AVARIAS =================
window.renderAvarias = async () => {
    setActiveMenu('m-ava');
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-trash-alt"></i> Avarias</h2>
        <div class="card grid-2">
            <div>
                <label>Insumo Perdido:</label>
                <div class="search-box"><i class="fas fa-search"></i><input type="text" id="avaria-busca" placeholder="Buscar..." onkeyup="filtrarListaRadio('avaria-busca', 'lista-avarias')"></div>
                <div class="custom-list" id="lista-avarias"></div>
            </div>
            <div>
                <label>Quantidade:</label> 
                <div style="display:flex; gap:5px; align-items:center;">
                    <input type="number" id="avaria-qtd" step="0.01" style="flex:1; margin:0;">
                    <select id="un-avaria" style="padding:10px; border:1px solid var(--border-color); border-radius:4px; max-width:110px; margin:0;"><option value="">-</option></select>
                </div>
                <label style="color:var(--primary); font-weight:bold; font-size:13px; margin-top:10px;"><i class="fas fa-info-circle"></i> Motivo detalhado (Obrigatório):</label> 
                <textarea id="avaria-motivo" rows="3" placeholder="Ex: Produto caiu no chão e estragou..." style="margin-top: 5px; width: 100%; border-radius: 6px; padding: 10px; border: 1px solid #ccc;"></textarea>
                <button class="btn-primary" style="margin-top:10px;" onclick="salvarAvaria()"><i class="fas fa-save"></i> Registrar Perda</button>
            </div>
        </div>
        <div class="card">
            <h3><i class="fas fa-history"></i> Histórico de Perdas</h3>
            <table id="tb-avarias"><tr><th>Item</th><th>Qtd</th><th>Motivo</th><th>Ações</th></tr></table>
        </div>
    `;
    const div = document.getElementById('lista-avarias');
    const snaps = await getDocs(collection(db, "insumos"));
    snaps.forEach(d => { 
        div.innerHTML += `<div class="custom-list-item"><input type="radio" name="r-ava" id="ava-${d.id}" value="${d.id}" onchange="atualizarOpcoesUnidadeUI('un-avaria', '${d.data().unidade||'un'}')"><label for="ava-${d.id}"><strong>${d.data().nome}</strong> <span style="font-size:11px; opacity:0.7;">(Estoque: ${d.data().unidade||'un'})</span></label></div>`; 
    });
    carregarHistAvarias();
};

window.salvarAvaria = async () => {
    const sel = document.querySelector('input[name="r-ava"]:checked');
    const qtdDigitada = parseFloat(document.getElementById('avaria-qtd').value);
    const unSelecionada = document.getElementById('un-avaria').value;
    const motivo = document.getElementById('avaria-motivo').value;
    
    if(!sel || isNaN(qtdDigitada) || !motivo.trim() || !unSelecionada) return await customAlert("Erro: O preenchimento do motivo detalhado, a quantidade e a seleção da medida são obrigatórios.");
    
    const iRef = doc(db, "insumos", sel.value); const iDoc = await getDoc(iRef);
    
    let qtdRealPerdida = converterUnidade(qtdDigitada, unSelecionada, iDoc.data().unidade);
    qtdRealPerdida = parseFloat(qtdRealPerdida.toFixed(3));
    
    if(iDoc.data().qtd < qtdRealPerdida) return await customAlert("Você está registrando uma perda maior do que a quantidade disponível no estoque.");
    
    let novoSaldo = parseFloat((iDoc.data().qtd - qtdRealPerdida).toFixed(3));
    
    await updateDoc(iRef, { qtd: novoSaldo });
    await addDoc(collection(db, "avarias"), { 
        insumoId: sel.value, 
        nome: iDoc.data().nome, 
        qtd: qtdRealPerdida, // Grava formatado
        unidade: iDoc.data().unidade || 'un', 
        motivo, 
        userUid: currentAuthUser.uid, 
        userEmail: window.encrypt(currentUserData.email_plain), 
        timestamp: new Date().toISOString() 
    });
    
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Avaria", iDoc.data().nome, `Qtd: ${qtdDigitada} ${unSelecionada} (Convertido: ${fmtQtd(qtdRealPerdida)} ${iDoc.data().unidade || 'un'}) - ${motivo}`);
    renderAvarias();
};

window.carregarHistAvarias = async () => {
    const snaps = await getDocs(query(collection(db, "avarias")));
    const tb = document.getElementById('tb-avarias');
    snaps.forEach(s => { 
        const d = s.data(); 
        tb.innerHTML += `<tr><td>${d.nome}</td><td>${fmtQtd(d.qtd)} ${d.unidade||''}</td><td>${d.motivo}</td><td style="white-space:nowrap;">
            <button class="btn-icon edit" onclick="editarAvaria('${s.id}', '${d.insumoId}', ${d.qtd})" title="Editar Quantidade (Direto na Medida Base)"><i class="fas fa-edit"></i></button>
            <button class="btn-icon undo" onclick="estornarAvaria('${s.id}', '${d.insumoId}', ${d.qtd})" title="Excluir/Estornar"><i class="fas fa-trash"></i></button>
        </td></tr>`; 
    });
};

window.editarAvaria = async (avId, insId, qtdAntiga) => {
    const nova = await customPrompt("Corrija a quantidade perdida real (na mesma unidade do banco):", fmtQtd(qtdAntiga));
    if(!nova || parseFloat(nova) === parseFloat(qtdAntiga)) return;
    let m = await customPrompt("Motivo da correção da quantidade:"); if(!m) return;
    
    const dif = parseFloat(nova) - parseFloat(qtdAntiga);
    const iRef = doc(db, "insumos", insId); const iDoc = await getDoc(iRef);
    if(iDoc.exists() && iDoc.data().qtd >= dif) {
        await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd - dif).toFixed(3)) });
        await updateDoc(doc(db, "avarias", avId), { qtd: parseFloat(nova) });
        await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Edição Avaria", iDoc.data().nome, `Ajuste Qtd de ${fmtQtd(qtdAntiga)} para ${fmtQtd(nova)}. Motivo: ${m}`);
        renderAvarias();
    } else await customAlert("Impossível ajustar, o saldo em estoque não comporta a mudança.");
};

window.estornarAvaria = async (avId, insId, qtd) => {
    let m = await customPrompt("Motivo da exclusão do registro de perda (Atenção: Isso devolverá os itens ao estoque):");
    if(!m) return;
    const iRef = doc(db, "insumos", insId); const iDoc = await getDoc(iRef);
    if(iDoc.exists()) await updateDoc(iRef, { qtd: parseFloat((iDoc.data().qtd + parseFloat(qtd)).toFixed(3)) });
    await deleteDoc(doc(db, "avarias", avId));
    await logAction(currentUserData.email_plain, safeDecrypt(currentUserData.nome), "Exclusão Avaria", iDoc.data().nome, `Motivo: ${m}`);
    renderAvarias();
};

// ================= TELA: COMUM - CONFIGURAÇÕES =================
let configUrlAvatar = "";

window.renderConfig = () => {
    setActiveMenu('m-cfg');
    configUrlAvatar = currentUserData.foto_url || "";
    document.getElementById('main-content').innerHTML = `
        <h2><i class="fas fa-cog"></i> Configurações</h2>
        <div class="card grid-2">
            <div>
                <h3><i class="fas fa-id-badge"></i> Perfil Atual</h3>
                <div style="display:flex; align-items:center; gap:15px; margin-bottom:15px;">
                    <img id="cfg-avatar-preview" src="${configUrlAvatar}" class="profile-pic" style="margin:0; width:90px; height:90px;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/149/149071.png'">
                    <div><p><strong>${safeDecrypt(currentUserData.nome)}</strong></p><p>${maskCPF(safeDecrypt(currentUserData.cpf))}</p><span class="badge">${currentUserData.role}</span></div>
                </div>
                
                <h3 style="margin-top:20px;"><i class="fas fa-edit"></i> Atualizar Dados</h3>
                <label class="custom-file-upload">
                    <i class="fas fa-camera"></i> Alterar Foto de Perfil
                    <input type="file" id="cfg-foto" accept="image/png, image/jpeg" onchange="atualizarFotoPerfil(this, 'cfg-avatar-preview')">
                </label>
                
                <label style="font-size:12px;">Novo E-mail:</label> <input type="email" id="cfg-email" value="${safeDecrypt(currentUserData.email)}">
                <label style="font-size:12px;">Novo Telefone:</label> <input type="text" id="cfg-tel" value="${safeDecrypt(currentUserData.telefone)}">
                
                <label style="font-size:12px;">Nova Senha:</label> 
                <div class="input-with-icon password-wrapper">
                    <i class="fas fa-lock lock-icon"></i><input type="password" id="cfg-new-pass" placeholder="digite nova senha" autocomplete="new-password" onkeyup="checkPasswordStrength('cfg-new-pass', 'cfg-pass-reqs')"><i class="fas fa-eye toggle-password" onclick="togglePassword('cfg-new-pass', this)"></i>
                </div>
                <ul id="cfg-pass-reqs" class="password-requirements">
                    <li id="req-len" class="invalid"><i class="fas fa-times"></i> Mínimo 8 caracteres</li>
                    <li id="req-upper" class="invalid"><i class="fas fa-times"></i> 1 letra maiúscula</li>
                    <li id="req-num" class="invalid"><i class="fas fa-times"></i> 1 número</li>
                    <li id="req-spec" class="invalid"><i class="fas fa-times"></i> 1 caractere especial</li>
                </ul>
            </div>
            
            <div style="background:rgba(211, 47, 47, 0.05); padding:25px; border-radius:12px; border: 1px solid var(--border-color); align-self:start;">
                <h3 style="color:var(--primary);"><i class="fas fa-shield-alt"></i> Confirmação Necessária</h3>
                <p style="font-size:13px; margin-bottom:15px; opacity:0.8;">Por motivos de segurança, insira sua <strong>Senha Atual</strong> para aplicar as mudanças de conta.</p>
                <div class="input-with-icon password-wrapper">
                    <i class="fas fa-lock lock-icon"></i><input type="password" id="cfg-old-pass" placeholder="Senha Atual (Obrigatória)"><i class="fas fa-eye toggle-password" onclick="togglePassword('cfg-old-pass', this)"></i>
                </div>
                <button class="btn-primary" onclick="salvarConfig()"><i class="fas fa-save"></i> Atualizar Minha Conta</button>
            </div>
        </div>
    `;
    IMask(document.getElementById('cfg-tel'), { mask: '(00) 00000-0000' });
};

window.salvarConfig = async () => {
    const oldPass = document.getElementById('cfg-old-pass').value;
    const newEmail = document.getElementById('cfg-email').value;
    const newTel = document.getElementById('cfg-tel').value;
    const newPass = document.getElementById('cfg-new-pass').value;

    if(!oldPass) return await customAlert("Digite sua senha atual.");
    if(newPass && !checkPasswordStrength('cfg-new-pass', 'cfg-pass-reqs')) return await customAlert("Nova senha não atende aos requisitos de força.");
    
    const fotoFinal = configUrlAvatar || currentUserData.foto_url || "";

    try {
        const cred = EmailAuthProvider.credential(auth.currentUser.email, oldPass);
        await reauthenticateWithCredential(auth.currentUser, cred);
        
        let newPayload = { ...currentUserData, telefone: window.encrypt(newTel), foto_url: fotoFinal };
        
        // Trata alteração e transição sensível no Auth e Firestore em caso de novo E-mail
        if (newEmail !== currentUserData.email_plain) {
            await updateEmail(auth.currentUser, newEmail);
            newPayload.email = window.encrypt(newEmail);
            await setDoc(doc(db, "users", newEmail), newPayload);
            await deleteDoc(doc(db, "users", currentUserData.email_plain));
            newPayload.email_plain = newEmail;
        } else {
            await updateDoc(doc(db, "users", currentUserData.email_plain), { telefone: window.encrypt(newTel), foto_url: fotoFinal });
        }
        
        currentUserData = newPayload;
        
        if (newPass) await updatePassword(auth.currentUser, newPass);
        
        if (fotoFinal) {
            const elPhoto = document.getElementById('user-display-photo');
            if(elPhoto) elPhoto.src = fotoFinal;
        }
        await customAlert("Configurações atualizadas com sucesso!");
        renderConfig();
    } catch (error) { await customAlert("Erro: Verifique se a sua senha atual está correta. (" + error.message + ")"); }
};