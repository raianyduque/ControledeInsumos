<?php
error_reporting(0);
ini_set('display_errors', 0);
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$uploadDir = 'uploads/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file =$_FILES['file'];
    $fileName = time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '', basename($file['name']));$targetPath = $uploadDir .$fileName;

    if (move_uploaded_file($file['tmp_name'],$targetPath)) {
        chmod($targetPath, 0644);
        $protocol = (isset($_SERVER['HTTPS']) &&$_SERVER['HTTPS'] === 'on') ? "https" : "http";
        $host =$_SERVER['HTTP_HOST'];
        $baseDir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
        $fullUrl = $protocol . "://" . $host . $baseDir . "/" . $targetPath;

        echo json_encode(['success' => true, 'url' => $fullUrl]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Falha ao salvar a imagem.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Nenhum arquivo enviado.']);
}
exit;