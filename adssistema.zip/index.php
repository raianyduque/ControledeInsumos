<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xis Fábrica - Sistema de Gestão</title>
    <link rel="stylesheet" href="style.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    <script src="https://unpkg.com/imask"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

    <!-- Modal Global Customizado (Substitui os Alertas Nativos) -->
    <div id="custom-modal-overlay" class="modal-overlay-custom" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 10000; align-items: center; justify-content: center; backdrop-filter: blur(3px);">
        <div class="modal-box" style="background: var(--card-bg); padding: 25px; border-radius: 12px; width: 90%; max-width: 420px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); text-align: center; border: 1px solid var(--border-color);">
            <h3 id="modal-title" style="margin-bottom: 15px; color: var(--primary); font-size: 1.4rem;"></h3>
            <div id="modal-message" style="margin-bottom: 20px; font-size: 15px; color: var(--text);"></div>
            <input type="text" id="modal-input" style="display: none; width: 100%; padding: 12px; margin-bottom: 20px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg); color: var(--text); outline: none;" />
            <div style="display: flex; gap: 10px; justify-content: center;">
                <button id="modal-btn-cancel" class="btn-secondary" style="display: none;"><i class="fas fa-times"></i> Cancelar</button>
                <button id="modal-btn-ok" class="btn-primary"><i class="fas fa-check"></i> Confirmar</button>
            </div>
        </div>
    </div>

    <div id="auth-container" class="auth-layout active">
        <div class="banner">
            <div class="banner-content">
                <img src="img/logo.png" alt="Logo" class="logo" id="logo-img" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3075/3075977.png'">
                <h1>Xis Fábrica</h1>
                <p>O autêntico sabor, a melhor gestão.</p>
            </div>
        </div>
        
        <div class="form-container">
            <div class="flip-wrapper" id="flip-wrapper">
                <div class="flipper">
                    <!-- Frente: Login -->
                    <div class="front">
                        <form id="login-form">
                            <h2><i class="fas fa-sign-in-alt"></i> Entrar</h2>
                            <div id="login-error" class="error-msg"></div>
                            
                            <div class="input-with-icon">
                                <i class="fas fa-envelope"></i>
                                <input type="email" id="login-email" placeholder="E-mail" required>
                            </div>
                            
                            <div class="input-with-icon password-wrapper">
                                <i class="fas fa-lock lock-icon"></i>
                                <input type="password" id="login-password" placeholder="Senha" required>
                                <i class="fas fa-eye toggle-password" onclick="togglePassword('login-password', this)"></i>
                            </div>
                            
                            <div style="text-align: right; margin-bottom: 15px;">
                                <a href="#" style="font-size: 13px; color: var(--primary);" onclick="showRecoverForm()">Esqueci minha senha</a>
                            </div>

                            <button type="submit" class="btn-primary"><i class="fas fa-arrow-right"></i> Acessar</button>
                            <p class="form-footer">Novo funcionário? <a href="#" onclick="document.getElementById('flip-wrapper').classList.add('flipped')">Cadastre-se</a></p>
                        </form>
                    </div>

                    <!-- Verso: Registro -->
                    <div class="back">
                        <form id="register-form">
                            <h2><i class="fas fa-user-plus"></i> Cadastro</h2>
                            <div id="reg-error" class="error-msg"></div>
                            
                            <div class="grid-2">
                                <input type="text" id="reg-nome" placeholder="Nome" required>
                                <input type="text" id="reg-sobrenome" placeholder="Sobrenome" required>
                            </div>
                            
                            <div class="input-with-icon">
                                <i class="fas fa-envelope"></i>
                                <input type="email" id="reg-email" placeholder="E-mail" required>
                            </div>
                            
                            <div class="grid-2">
                                <div class="input-with-icon"><i class="fas fa-phone"></i><input type="text" id="reg-telefone" placeholder="Telefone" required></div>
                                <div class="input-with-icon"><i class="fas fa-id-card"></i><input type="text" id="reg-cpf" placeholder="CPF" required></div>
                            </div>
                            
                            <div class="input-with-icon password-wrapper">
                                <i class="fas fa-lock lock-icon"></i>
                                <input type="password" id="reg-senha" placeholder="Senha" required onkeyup="checkPasswordStrength('reg-senha', 'pass-reqs')">
                                <i class="fas fa-eye toggle-password" onclick="togglePassword('reg-senha', this)"></i>
                            </div>
                            
                            <ul id="pass-reqs" class="password-requirements">
                                <li id="req-len" class="invalid"><i class="fas fa-times"></i> Mínimo 8 caracteres</li>
                                <li id="req-upper" class="invalid"><i class="fas fa-times"></i> 1 letra maiúscula</li>
                                <li id="req-num" class="invalid"><i class="fas fa-times"></i> 1 número</li>
                                <li id="req-spec" class="invalid"><i class="fas fa-times"></i> 1 caractere especial</li>
                            </ul>

                            <div class="input-with-icon">
                                <i class="fas fa-lock lock-icon"></i>
                                <input type="password" id="reg-senha-rep" placeholder="Repita a Senha" required>
                            </div>
                            
                            <button type="submit" class="btn-primary" style="margin-top: 10px;"><i class="fas fa-check"></i> Cadastrar</button>
                            <p class="form-footer">Já tem conta? <a href="#" onclick="document.getElementById('flip-wrapper').classList.remove('flipped')">Voltar ao Login</a></p>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Formulário de Recuperação de Senha -->
            <form id="recover-form" style="display: none; animation: fadeIn 0.5s; width: 100%; max-width: 420px; background: var(--card-bg); padding: 2rem; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1);">
                <div id="recover-step-1">
                    <h2><i class="fas fa-key"></i> Recuperar Senha</h2>
                    <p style="font-size:13px; color:#555; text-align:center; margin-bottom:15px;">Informe seu e-mail e CPF cadastrados.</p>
                    <input type="email" id="rec-email" placeholder="E-mail" required>
                    <input type="text" id="rec-cpf" placeholder="CPF" required>
                    <button type="button" class="btn-primary" onclick="enviarCodigoRecuperacao()"><i class="fas fa-paper-plane"></i> Enviar Código</button>
                    <button type="button" class="btn-secondary" style="margin-top:10px;" onclick="voltarAoLogin()"><i class="fas fa-arrow-left"></i> Voltar</button>
                </div>
                
                <div id="recover-step-2" style="display:none; text-align:center;">
                    <h2><i class="fas fa-shield-alt"></i> Código de Segurança</h2>
                    <p style="font-size:13px; color:#555; margin-bottom:15px;">Um código foi enviado (simulação) para seu e-mail.</p>
                    <input type="text" id="rec-code" placeholder="000000" maxlength="6" style="text-align:center; font-size:20px; letter-spacing:5px;">
                    
                    <div class="input-with-icon password-wrapper" style="margin-top:15px;">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="rec-new-pass" placeholder="Nova Senha" autocomplete="new-password" onkeyup="checkPasswordStrength('rec-new-pass', 'rec-pass-reqs')">
                    </div>
                    <ul id="rec-pass-reqs" class="password-requirements" style="text-align:left;">
                        <li id="req-len" class="invalid"><i class="fas fa-times"></i> Mínimo 8 caracteres</li>
                        <li id="req-upper" class="invalid"><i class="fas fa-times"></i> 1 letra maiúscula</li>
                        <li id="req-num" class="invalid"><i class="fas fa-times"></i> 1 número</li>
                        <li id="req-spec" class="invalid"><i class="fas fa-times"></i> 1 caractere especial</li>
                    </ul>

                    <button type="button" class="btn-primary" style="margin-top:15px;" onclick="validarCodigoENovaSenha()"><i class="fas fa-save"></i> Redefinir Senha</button>
                    <button type="button" class="btn-secondary" style="margin-top:10px;" onclick="voltarAoLogin()"><i class="fas fa-times"></i> Cancelar</button>
                </div>
            </form>

            <form id="two-factor-form" style="display: none; animation: fadeIn 0.5s; width: 100%; max-width: 420px; background: var(--card-bg); padding: 2rem; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); text-align: center;">
                <h2><i class="fas fa-shield-alt"></i> 2 Etapas</h2>
                <p style="color: #555; font-size: 14px; margin-bottom: 20px;">Código enviado para <br><strong id="2fa-email-display"></strong></p>
                <div class="timer-wrapper">
                    <svg class="progress-ring" width="120" height="120"><circle class="progress-ring__circle" stroke="#D32F2F" stroke-width="8" fill="transparent" r="52" cx="60" cy="60"/></svg>
                    <div class="timer-text" id="2fa-timer-text">03:00</div>
                </div>
                <div id="2fa-error" class="error-msg" style="margin-top:15px;"></div>
                <input type="text" id="2fa-code-input" placeholder="000000" maxlength="6" style="text-align:center; font-size:20px; letter-spacing: 5px; font-weight:bold; margin-top:15px;">
                <button type="button" class="btn-primary" onclick="validarCodigo2FA()"><i class="fas fa-check-circle"></i> Verificar</button>
                <button type="button" id="btn-resend-2fa" class="btn-secondary" style="margin-top: 10px;" onclick="iniciar2FA()"><i class="fas fa-sync-alt"></i> Reenviar Código</button>
                <button type="button" style="margin-top: 15px; background:none; border:none; color:#D32F2F; cursor:pointer; text-decoration:underline;" onclick="cancelar2FA()">Voltar ao Login</button>
            </form>
        </div>
    </div>

    <!-- Interface Principal -->
    <div id="app-container" style="display: none;">
        <!-- Header Mobile -->
        <header class="mobile-header">
            <button class="btn-icon" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
            <h3 style="color:var(--primary); font-size:1.1rem;">Xis Fábrica</h3>
            <button class="theme-toggle-btn" onclick="toggleDarkMode()" title="Modo Noturno"><i class="fas fa-moon"></i></button>
        </header>

        <div class="sidebar-overlay" id="sidebar-overlay" onclick="toggleSidebar()"></div>

        <nav class="sidebar" id="sidebar">
            <div style="display:flex; justify-content:flex-end; margin-bottom:10px;">
                <button class="theme-toggle-btn" onclick="toggleDarkMode()" title="Alternar Modo Noturno"><i class="fas fa-moon"></i></button>
            </div>
            <div class="user-info">
                <img id="user-display-photo" src="" alt="Perfil" class="profile-pic" onerror="this.src='https://cdn-icons-png.flaticon.com/512/149/149071.png'">
                <h3 id="user-display-name">Nome</h3>
                <span id="user-display-role" class="badge">Função</span>
            </div>
            <ul id="menu-items"></ul>
            <button onclick="logout()" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Sair</button>
        </nav>
        
        <main class="content">
            <div id="main-content"></div>
        </main>
    </div>

    <div id="print-area" style="display:none;"></div>

    <script type="module" src="app.js"></script>
</body>
</html>